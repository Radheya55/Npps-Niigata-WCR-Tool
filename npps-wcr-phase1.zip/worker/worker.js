// Neptunus WCR Tool - Cloudflare Worker
// This file runs on Cloudflare. Your Gemini API key is stored as an
// environment variable called GEMINI_API_KEY — never in this code.

const ALLOWED_ORIGIN = "https://neptunus-wcr.github.io"; // CHANGE THIS to your actual GitHub Pages URL

addEventListener("fetch", (event) => {
  event.respondWith(handleRequest(event.request));
});

async function handleRequest(request) {
  // Handle CORS preflight
  if (request.method === "OPTIONS") {
    return new Response(null, {
      headers: {
        "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
    });
  }

  // Only allow POST from your GitHub Pages domain
  const origin = request.headers.get("Origin");
  if (origin !== ALLOWED_ORIGIN) {
    return new Response("Forbidden", { status: 403 });
  }

  if (request.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  try {
    const body = await request.json();
    const { prompt, type } = body;

    if (!prompt || !type) {
      return new Response(JSON.stringify({ error: "Missing prompt or type" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    // Call Gemini API — key is in environment, never exposed to browser
    const geminiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: type === "refinement" ? 0.3 : 0.7,
            maxOutputTokens: 8192,
          },
        }),
      }
    );

    const geminiData = await geminiResponse.json();

    return new Response(JSON.stringify(geminiData), {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
      },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
      },
    });
  }
}
