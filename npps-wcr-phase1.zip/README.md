# NPPS WCR Tool — Setup Guide

## What You Need Before Starting

1. A GitHub account (you already have one)
2. A Cloudflare account (you already have one)
3. Access to Google Cloud Console (free)
4. Your Gemini API key

---

## STEP 1 — Create the GitHub Repository

1. Go to github.com → click **New repository**
2. Name it: `npps-wcr-tool`
3. Set to **Public** (required for free GitHub Pages)
4. Click **Create repository**
5. Upload all files from the `public/` folder and the `.github/` folder exactly as structured here
6. Go to **Settings → Pages → Source → GitHub Actions**
7. Push to `main` branch — the site will deploy automatically
8. Your URL will be: `https://YOUR-USERNAME.github.io/npps-wcr-tool/`

---

## STEP 2 — Set Up Cloudflare Worker (for Gemini API key security)

1. Log in to dash.cloudflare.com
2. Go to **Workers & Pages → Create → Create Worker**
3. Name it: `npps-wcr-gemini`
4. Click **Deploy**, then **Edit code**
5. Delete all existing code and paste the contents of `worker/worker.js`
6. **Change line 4**: replace `https://neptunus-wcr.github.io` with your actual GitHub Pages URL
7. Click **Save and Deploy**
8. Copy your Worker URL (shown at top — looks like `https://npps-wcr-gemini.YOUR-ACCOUNT.workers.dev`)

### Add your Gemini API Key to Cloudflare (the secure way):
1. In your Worker page → go to **Settings → Variables**
2. Under **Environment Variables** → click **Add variable**
3. Variable name: `GEMINI_API_KEY`
4. Value: your actual Gemini API key
5. Click **Encrypt** (very important — this hides it forever)
6. Click **Save and Deploy**

---

## STEP 3 — Set Up Google OAuth (one-time, 15 minutes)

1. Go to console.cloud.google.com
2. Click **New Project** → name it `NPPS WCR Tool` → Create
3. Go to **APIs & Services → Enable APIs**:
   - Enable **Google Drive API**
   - Enable **Google Sheets API**
4. Go to **APIs & Services → OAuth consent screen**:
   - User type: **Internal** (since it's only your company)
   - App name: `NPPS WCR Tool`
   - Fill in your email → Save
5. Go to **APIs & Services → Credentials → Create Credentials → OAuth Client ID**:
   - Application type: **Web application**
   - Name: `NPPS WCR Tool`
   - Authorised JavaScript origins: add `https://YOUR-USERNAME.github.io`
   - Click **Create**
6. Copy the **Client ID** (ends in `.apps.googleusercontent.com`)

---

## STEP 4 — Set Up Google Drive Folder

1. Open Google Drive on your company laptop
2. Create a new folder called `NPPS_WCR_Data`
3. Right-click the folder → **Get link**
4. The URL looks like: `https://drive.google.com/drive/folders/1ABC123xyz...`
5. Copy the part after `/folders/` — that is your **Folder ID**

---

## STEP 5 — Update app.js with Your Values

Open `public/app.js` and update the CONFIG block at the top:

```javascript
const CONFIG = {
  GOOGLE_CLIENT_ID: "paste-your-client-id-here.apps.googleusercontent.com",
  WORKER_URL: "https://npps-wcr-gemini.YOUR-ACCOUNT.workers.dev",
  DRIVE_FOLDER_ID: "paste-your-folder-id-here",
  BASE_DATA_SHEET_NAME: "NPPS_WCR_BaseData",
  DRAFT_EXPIRY_DAYS: 15,
  MAX_DRAFTS: 10,
};
```

Save the file and push to GitHub. The site redeploys automatically in ~1 minute.

---

## STEP 6 — Test It

1. Open `https://YOUR-USERNAME.github.io/npps-wcr-tool/`
2. Click **Add Base Data** (Service Manager flow)
3. Enter any employee number → click Continue
4. Click **Connect Google Drive** → Allow the popup
5. Add a test project → Save
6. Go back to home → click **Create WCR**
7. Enter the project code → Look Up → verify data auto-fills

---

## File Structure

```
npps-wcr-tool/
├── public/
│   ├── index.html     ← Main app (all screens)
│   ├── style.css      ← Styles
│   └── app.js         ← All logic
├── worker/
│   └── worker.js      ← Paste this into Cloudflare (not deployed to GitHub Pages)
└── .github/
    └── workflows/
        └── deploy.yml ← Auto-deploys public/ to GitHub Pages on every push
```

---

## What Phase 1 Gives You

- ✅ Home page with Create WCR and Add Base Data buttons
- ✅ Employee number login
- ✅ Google OAuth (one-time Allow per person)
- ✅ Add Base Data form → saves to Google Sheet in your Drive
- ✅ Project code lookup → auto-fills project details
- ✅ Draft creation and listing (10 per person, 15-day expiry)
- ✅ All data stored in your Google Drive — visible directly
- ✅ Gemini API key secured in Cloudflare — never visible to users

## What Comes Next

- Phase 2: All WCR sections with editable tables
- Phase 3: DWR PDF upload and Gemini-powered suggestions
- Phase 4: Language refinement sidebar and Google Doc export
